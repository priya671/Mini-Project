package com.cap.cl.main;

/**
 * all copy rights reserved to user priya kothare
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cap.cl.database.DatabaseConnection;

public class AdminInformation {
	private static Connection conn;
	private static PreparedStatement pst;
	private static ResultSet rs;
	static {
		try {
			conn = DatabaseConnection.getDatabaseConnection();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//Validating admin user using username and password
	public String validateUser(String username, String password) throws SQLException {
		String sel = "select * from adminuserlist where username=? and password=?";
		pst = conn.prepareStatement(sel);
		pst.setString(1, username);
		pst.setString(2, password);
		rs = pst.executeQuery();
		if(rs.next())
			return username;
		return null;
	}
	
}
