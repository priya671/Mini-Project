package com.cap.cl.dao;

/**
 * all copy rights reserved to user priya kothare
 */

import java.io.IOException;
import java.sql.SQLException;

public interface AdminDAO {
	
	public void registerNewAdmin(String username,String password) throws SQLException, IOException; //Add new admin
	
	public void enrollStudent() throws SQLException, IOException; //adding student data in the database
	
	public void viewStudentBalance(int id) throws SQLException; //view only balance using id
	
	public void getStudentInfoById(int id) throws SQLException;//Get all student info using id
	
	public void filterBasedOnStatus(String status) throws SQLException;//view all the students of same status
	
	public void payStudentFees(int id) throws SQLException; //pay student fees using id
	
	public void viewAllStudentData() throws SQLException;//View entire database records
	
	public void updateStudentData(int id) throws SQLException, NumberFormatException, IOException; //update student record using id
	
	public void deleteStudentData(int id) throws SQLException; //delete student record using id

}
