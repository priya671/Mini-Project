package com.cap.cl.main;

/**
 * all copy rights reserved to user priya kothare
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cap.cl.database.DatabaseConnection;

public class StudentInformation {
	private static Connection conn;
	private static PreparedStatement pst;
	private static ResultSet rs;
	static {
		try { //creating common connection object
			conn = DatabaseConnection.getDatabaseConnection();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	
	//Validating user after registration
	public String validateStudent(int id, String password) throws SQLException {
		String sel = "select * from studentlist where id=? and password=?";
		pst = conn.prepareStatement(sel);
		pst.setInt(1, id);
		pst.setString(2, password);
		rs = pst.executeQuery();
		if(rs.next())
			return rs.getString("name");
		return null;
	}

}

