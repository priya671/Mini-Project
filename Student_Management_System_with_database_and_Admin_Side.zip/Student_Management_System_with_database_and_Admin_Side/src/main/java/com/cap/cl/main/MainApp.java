package com.cap.cl.main;


/**
 * all copy rights reserved to user priya kothare

 */

import com.cap.cl.dao.AdminDAOImpl;
import com.cap.cl.dao.StudentDAOImpl;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

public class MainApp {
	
	private static int id;
	private static String username;
	private static String password;
	private static Boolean isLoggedin = false;
	private static Boolean isLoggedinAdmin = false;
	private static Boolean isLoggedinStudent = false;
	static BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
	static StudentInformation studentinformation = new StudentInformation();
	static AdminInformation admininformation = new AdminInformation();
	
	public static void main(String[] args) throws Exception{
		System.out.println("**************Welcome to School Management System**************");
		
		while(true) {
			System.out.println(" 1.Login as Admin\n 2.Login as Student\n 3.Exit");
			System.out.println("Enter your choice: ");
			int choice = Integer.parseInt(bfr.readLine());
			switch(choice) {
				case 1: //Admin Login
					System.out.println("Enter username: ");
					username = bfr.readLine();
					System.out.println("Enter password: ");
					password = bfr.readLine();
					try {
						String loggedusername = admininformation.validateUser(username, password);
						if(loggedusername==null) {
							System.out.println("*********");
							System.out.println("Invalid Credentials! Please Try Again Later");
							System.out.println("*********");
						}
						else {
							isLoggedinAdmin = true;
							System.out.println("**********");
							System.out.println("Welcome Admin " + loggedusername);
							System.out.println("**********");
							AfterAdminLoginSelection();
						}
					}catch(NullPointerException e) {
						System.out.println("*********");
						System.out.println("Invalid Credentials! Please try again");
						System.out.println("*********");
					}
					break;
				case 2:
					//Student Login
					System.out.println("Enter Unique Student Id: ");
					id = Integer.parseInt(bfr.readLine());
					System.out.println("Enter Student Password: ");
					password = bfr.readLine();
					try {
						String loggedusername = studentinformation.validateStudent(id, password);
						if(loggedusername==null) {
							System.out.println("*********");
							System.out.println("Invalid Credentials! Please Try Again Later");
							System.out.println("*********");
						}
						else {
							isLoggedinStudent = true;
							System.out.println("**********");
							System.out.println("Welcome " + loggedusername);
							System.out.println("**********");
							AfterStudentLoginSelection();
						}
					}catch(NullPointerException e) {
						System.out.println("*********");
						System.out.println("Invalid Credentials! Please try again");
						System.out.println("*********");
					}
					break;
				case 3:
					System.exit(0);
				default:
					System.out.println("****Invalid Choice");
			}
		}
		//while(!isLoggedinAdmin || !isLoggedinStudent);
		
}
	//Selections after admin login
	public static void AfterAdminLoginSelection() throws SQLException, IOException {
		AdminDAOImpl admindaoimpl = new AdminDAOImpl(admininformation);
		
		//Display further choices after successful Admin login
		while(isLoggedinAdmin=true) {
			System.out.println("1.Enroll new Student");
			System.out.println("2.View Student Balance By Id");
			System.out.println("3.Pay Student Tution fees");
			System.out.println("4.Filter Students Based on Student status");
			System.out.println("5.Get Student Information by ID");
			System.out.println("6.View All the Existing Student Data");
			System.out.println("7.Update any student Data");
			System.out.println("8.Delete any Student Data");
			System.out.println("9.Register New Admin User");
			System.out.println("10.Exit");
			System.out.println("Enter your choice: ");
			int choice1 = Integer.parseInt(bfr.readLine());
			
			switch(choice1) {
				case 1:
					admindaoimpl.enrollStudent(); //enroll new student
					break;
				case 2: //View Student Balance by ID
					System.out.println("Enter Student Id to view Balance: ");
					int sid = Integer.parseInt(bfr.readLine());
					admindaoimpl.viewStudentBalance(sid);
					break;
				case 3: //Pay Student fees by ID
					System.out.println("Enter Student Id to pay the tution fees: ");
					int sidtution = Integer.parseInt(bfr.readLine());
					admindaoimpl.payStudentFees(sidtution);
					break;
				case 4: //Display student information based on Status
					System.out.println("Enter Student status: ");
					String sidstatus = bfr.readLine();
					admindaoimpl.filterBasedOnStatus(sidstatus);
					break;
				case 5: //Display single student information by ID
					System.out.println("Enter Student Id to know the student information: ");
					int sidinfo = Integer.parseInt(bfr.readLine());
					admindaoimpl.getStudentInfoById(sidinfo);
					break;
				case 6: //View All Student Table Records
					admindaoimpl.viewAllStudentData();
					break;
				case 7: //Update any student information by ID
					System.out.println("Enter the id of the student to update: ");
					int sidupdate = Integer.parseInt(bfr.readLine());
					admindaoimpl.updateStudentData(sidupdate);
					break;
				case 8: //Delete Student by ID
					System.out.println("Enter the id of the student to delete:");
					int siddelete = Integer.parseInt(bfr.readLine());
					admindaoimpl.deleteStudentData(siddelete);
					break;
				case 9://Add new admin details in the database
					System.out.println("Enter username: ");
					String uname = bfr.readLine();
					System.out.println("Enter password: ");
					String pass = bfr.readLine();
					admindaoimpl.registerNewAdmin(uname, pass);
					break;
				case 10:
					System.exit(0);
					break;
				default:
					System.out.println("***Invalid Choice! Please try again");
					System.out.println("\n");
			}
		}
	}
	
	//Selections after student login
	public static void AfterStudentLoginSelection() throws Exception {
		StudentDAOImpl studentdaoimpl = new StudentDAOImpl(studentinformation);
		
		while(isLoggedinStudent=true) {
			System.out.println("1.View Student Balance By Id"); 
			System.out.println("2.Pay Student Tution fees");
			System.out.println("3.Get Student Information by ID");
			System.out.println("4.Check Paid fee amount");
			System.out.println("5.Exit");
			System.out.println("Enter your choice: ");
			int choice1 = Integer.parseInt(bfr.readLine());
			
			switch(choice1) {
				case 1: //Enter student ID and Password to view balance
					System.out.println("Enter Student Id to view Balance: ");
					int sid = Integer.parseInt(bfr.readLine());
					System.out.println("Enter Student Password: ");
					String password = bfr.readLine();
					studentdaoimpl.viewStudentBalance(sid,password); //Getting student password so that student can only view their own data
					break;
				case 2: //Enter student ID and Password to pay tution fees
					System.out.println("Enter Student Id to pay the tution fees: ");
					int sidtution = Integer.parseInt(bfr.readLine());
					System.out.println("Enter Student Password: ");
					String password2 = bfr.readLine();
					studentdaoimpl.payStudentFees(sidtution,password2);
					break;
				case 3: //Enter Student ID and Password to get overall student information
					System.out.println("Enter Student Id to know the student information: ");
					int sidinfo = Integer.parseInt(bfr.readLine());
					System.out.println("Enter Student Password: ");
					String password3 = bfr.readLine();
					studentdaoimpl.getStudentInfoById(sidinfo,password3);
					break;
				case 4: //Enter student ID and password to get Student fees
					System.out.println("Enter Student Id: ");
					int sidfee = Integer.parseInt(bfr.readLine());
					System.out.println("Enter Student Password: ");
					String password4 = bfr.readLine();
					studentdaoimpl.getStudentfeeById(sidfee,password4);
					break;
				case 5: //Exit
					System.exit(0);
					break;
				default:
					System.out.println("***Invalid Choice! Please try again");
					System.out.println("\n");
			}
		}
		
	}


}

