package com.cap.cl.dao;

/**
 * all copy rights reserved to user priya kothare
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cap.cl.database.DatabaseConnection;
import com.cap.cl.main.AdminInformation;

public class AdminDAOImpl implements AdminDAO{
	
	//creating admininformation object to access methods
		AdminInformation admininformation;
		BufferedReader bfr = new BufferedReader(new InputStreamReader(System.in));
		//to generate unique id
		int max = 99999;
		int min = 10000;
		
		private static Connection conn;
		private static PreparedStatement pst;
		private static ResultSet rs;
		static {
			try { //creating common connection object
				conn = DatabaseConnection.getDatabaseConnection();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	

	public AdminDAOImpl() {
			super();
			// TODO Auto-generated constructor stub
		}
	
	public AdminDAOImpl(AdminInformation admininformation) {
		super();
		this.admininformation = admininformation;
	}

	//Add New Student in the database
	public void enrollStudent() throws SQLException, IOException {
		System.out.println("************");
		
		int id = (int) (Math.random()*(max-min+1)+min);

		System.out.println("Enter student name: ");
		String name = bfr.readLine();
		
		System.out.println("Enter student course: ");
		String course = bfr.readLine();
		
		System.out.println("Enter student balance: ");
		Double balance = Double.parseDouble(bfr.readLine());

		System.out.println("Enter student status: ");
		String status = bfr.readLine();
		
		System.out.println("Enter student tution fee paid amount: ");
		Double paid_fee = Double.parseDouble(bfr.readLine());
		balance = balance - paid_fee;
		
		System.out.println("Enter student password: ");
		String password = bfr.readLine();
		
		
		String sel = "select * from studentlist where id=?";
		pst = conn.prepareStatement(sel);
		pst.setInt(1, id);
		rs = pst.executeQuery();
		if(rs.next()) {
			System.out.println("User with id " + id + " already exists!");
		}
		else {
		String ins = "insert into studentlist values(?,?,?,?,?,?,?)";
		pst = conn.prepareStatement(ins);
		pst.setInt(1, id);
		pst.setString(2, name);
		pst.setString(3, course);
		pst.setDouble(4, balance);
		pst.setString(5, status);
		pst.setDouble(6, paid_fee);
		pst.setString(7, password);
		int r = pst.executeUpdate();
		if(r>0) {
			System.out.println("Student Registered Successfully!");
			System.out.println("Student unique id is: " + id);
			}
		
		}
	}
		
		
	//View student balance by student id
	public void viewStudentBalance(int id) throws SQLException {
		System.out.println("************");
		String sel = "select balance,name from studentlist where id=?";
		pst = conn.prepareStatement(sel);
		pst.setInt(1, id);
		rs = pst.executeQuery();
			if(rs.next()) {
				System.out.println(rs.getString("name") + "'s balance= " + rs.getInt("balance"));
			}
		else {
			System.out.println("No Student found with mentioned Id");
		}
			
			System.out.println("************");
		
	}

	//Fetch all the students info of same status
	public void filterBasedOnStatus(String status) throws SQLException {
		System.out.println("*****************");
		String sel = "select * from studentlist where status=?";
		pst = conn.prepareStatement(sel);
		pst.setString(1, status);
		rs = pst.executeQuery();
		if(!rs.isBeforeFirst()) { //this returns false if the cursor is not before the first record or if there are no rows in the ResultSet
			System.out.println("No such status found in the database");
		}
		else {
		System.out.println("+-------+---------------+-----------------+---------+----------+-----------++-------+---------------+-----------------+---------+----------+---------+-----+--------+----------+---------+-----");
		System.out.printf("| %-10s |         %-8s                |           %4s       |   %-10s   |        %-8s          |  %4s   |%n","Student Id","Student Name","Student Course","Student Balance","Student Status","Fee Paid");
		System.out.println("+-------+---------------+-----------------+---------+----------+-----------++-------+---------------+-----------------+---------+----------+---------+-----+--------+----------+---------+-----");
		while(rs.next()) {
				System.out.printf("| %-10s |         %-8s               |           %4s      |     %-10s      |          %-8s            |      %4s    |%n",rs.getInt("id"),rs.getString("name"),rs.getString("course"),rs.getDouble("balance"),rs.getString("status"),rs.getDouble("fees_paid"));
				System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			System.out.println("+-------+---------------+-----------------+---------+----------+-----------++-------+---------------+-----------------+---------+----------+-----------+----------+-----------+");
			
		}
		
		}
		System.out.println("************");
		
	}

	//Pay Student Fees by ID
	public void payStudentFees(int id) throws SQLException {
		System.out.println("************");
		try {
			String sel = "select * from studentlist where id=?";
			pst = conn.prepareStatement(sel);
			pst.setInt(1, id);
			rs = pst.executeQuery();
		
			if(rs.next()) {
					System.out.println("Available Student Balance: " + rs.getDouble("balance"));
					System.out.println("Enter the tution fee amount to pay: ");
					int amt = Integer.parseInt(bfr.readLine());
					if(amt>rs.getDouble("balance")) {
						System.out.println("Insufficient Balance!");
					}
					else if(amt<=0) {
						System.out.println("Invalid Amount. Please try again!");
					}
					else {
						double available_amount = (rs.getDouble("balance")-amt);
						System.out.println("Available balance: " + available_amount);
						String upd = "update studentlist set balance=?,fees_paid=? where id=?";
						pst = conn.prepareStatement(upd);
						pst.setDouble(1, available_amount);
						double g = rs.getDouble("fees_paid");
						pst.setDouble(2, g+amt);
						pst.setInt(3, id);
						int r = pst.executeUpdate();
						if(r>0) {
							System.out.println(amt + " paid successfully!");
						}
					}
				}
			else {
				System.out.println("No student found with mentioned Id");
			}
				
		}catch(Exception e) { //if Student object is null it will invoke catch block
				System.out.println("No student found with mentioned Id");
	}
		System.out.println("************");
		
	}

	//View student data by student id
	public void viewAllStudentData() throws SQLException {
		System.out.println("******");
		System.out.println("+-------+---------------+-----------------+---------+----------+-----------++-------+---------------+-----------------+---------+----------+-------+-----+------+----------+---------+-----");
		System.out.printf("| %-10s |         %-8s                |           %4s       |   %-10s   |        %-8s          |  %4s   |%n","Student Id","Student Name","Student Course","Student Balance","Student Status","Fee Paid");
		String sel = "select * from studentlist";
		pst = conn.prepareStatement(sel);
		rs = pst.executeQuery();
		System.out.println("+-------+---------------+-----------------+---------+----------+-----------++-------+---------------+-----------------+---------+----------+---------+-----+--------+----------+---------+-----");
		while(rs.next()) {
			System.out.printf("| %-10s |         %-8s               |           %4s      |     %-10s      |          %-8s            |      %4s    |%n",rs.getInt("id"),rs.getString("name"),rs.getString("course"),rs.getDouble("balance"),rs.getString("status"),rs.getDouble("fees_paid"));
			System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		}
		System.out.println("+-------+---------------+-----------------+---------+----------+-----------++-------+---------------+-----------------+---------+----------+-----------+----------+-----------+");
		
		System.out.println("******");
		
	}

	//Update student data by Id
	public void updateStudentData(int id) throws SQLException, NumberFormatException, IOException {
		System.out.println("************");
		
		String sel = "select * from studentlist where id=?";
		pst = conn.prepareStatement(sel);
		pst.setInt(1, id);
		rs = pst.executeQuery();
			if(rs.next()) { //If id exists
				System.out.println("Select the content to update");
				System.out.println("1.Student name \n2.Student course \n3.Student balance \n4.Student Status \n5.Fees Paid by Student \n6.Student Password \n7.Exit");
				System.out.println("Enter your choice: ");
				int choice=Integer.parseInt(bfr.readLine());
				switch(choice) {
				case 1:
					System.out.println("Old name: " + rs.getString("name"));
					System.out.println("Enter updated name: ");
					String name = bfr.readLine();
					String updname = "update studentlist set name=? where id=?";
					pst = conn.prepareStatement(updname);
					pst.setString(1, name);
					pst.setInt(2, id);
					int r = pst.executeUpdate();
					if(r>0)
					//s.setStudentname(name);
						System.out.println("Student name updated.");
					//flag = 1;
					break;
				case 2:
					System.out.println("Old course: " + rs.getString("course"));
					System.out.println("Enter update course: ");
					String course = bfr.readLine();
					String updcourse = "update studentlist set course=? where id=?";
					pst = conn.prepareStatement(updcourse);
					pst.setString(1, course);
					pst.setInt(2, id);
					int r1 = pst.executeUpdate();
					//s.setCourse(course);
					if(r1>0)
						System.out.println("Student course updated");
					//flag = 1;
					break;
				case 3:
					System.out.println("Old balance: " + rs.getDouble("balance"));
					System.out.println("Enter updated balance: ");
					double balance = Double.parseDouble(bfr.readLine());
					String updbalance = "update studentlist set balance=? where id=?";
					pst = conn.prepareStatement(updbalance);
					pst.setDouble(1, balance);
					pst.setInt(2, id);
					int r2 = pst.executeUpdate();
					if(r2>0)
					//s.setStudentbalance(balance);
						System.out.println("Student balance updated");
					//flag = 1;
					break;
				case 4:
					System.out.println("Old status: " + rs.getString("status"));
					System.out.println("Enter updated status: ");
					String status = bfr.readLine();
					String updstatus = "update studentlist set status=? where id=?";
					pst = conn.prepareStatement(updstatus);
					pst.setString(1, status);
					pst.setInt(2, id);
					int r3 = pst.executeUpdate();
					if(r3>0)
					//s.setStudentstatus(status);
						System.out.println("Student Status updated");
					//flag = 1;
					break;
				case 5:
					System.out.println("Old fees paid amount: " + rs.getDouble("fees_paid"));
					System.out.println("Enter updated fees paid amount: ");
					Double fees = Double.parseDouble(bfr.readLine());
					String updfees = "update studentlist set fees_paid=? where id=?";
					pst = conn.prepareStatement(updfees);
					pst.setDouble(1, fees);
					pst.setInt(2, id);
					int r4 = pst.executeUpdate();
					if(r4>0)
						System.out.println("Student paid fees amount updated");
					break;
				case 6:
					System.out.println("Old Password: " + rs.getString("password"));
					System.out.println("Enter updated password: ");
					String password = bfr.readLine();
					String updpass = "update studentlist set password=? where id=?";
					pst = conn.prepareStatement(updpass);
					pst.setString(1, password);
					pst.setInt(2, id);
					int r5 = pst.executeUpdate();
					if(r5>0) {
						System.out.println("Student password updated");
					}
					break;
				case 7:
					System.exit(0);
				default:
					System.out.println("****Invalid Choice! Please try again");
					System.out.println("\n");
			}
		}
			else {
				System.out.println("Student id doesn't exist! Please try again.");
			}
		System.out.println("************");
		
	}

	//Delete Student By ID
	public void deleteStudentData(int id) throws SQLException {
		System.out.println("************");
		String sel = "select * from studentlist where id=?";
		pst = conn.prepareStatement(sel);
		pst.setInt(1, id);
		rs = pst.executeQuery();
		if(rs.next()) {
			String del = "delete from studentlist where id=?";
			pst = conn.prepareStatement(del);
			pst.setInt(1, id);
			int r = pst.executeUpdate();
			if(r>0)
				System.out.println("Student of id=" + id + " deleted successfully");
		}
		else {
			System.out.println("Student ID does not exist");
		}
		
		System.out.println("************");		
		
	}


	//Fetch all the student information by ID
	public void getStudentInfoById(int id) throws SQLException {
		System.out.println("************");
		
		String sel = "select * from studentlist where id=?";
		pst = conn.prepareStatement(sel);
		pst.setInt(1, id);
		rs = pst.executeQuery();
		if(rs.next()) {
			System.out.println("+-------+---------------+-----------------+---------+----------+-----------++-------+---------------+-----------------+---------+----------+---------+-----+--------+----------+---------+-----");
			System.out.printf("| %-10s |             %-8s                |             %4s       |   %-10s   |          %-8s          |  %4s   |%n","Student Id","Student Name","Student Course","Student Balance","Student Status","Fee Paid");
			System.out.println("+-------+---------------+-----------------+---------+----------+-----------++-------+---------------+-----------------+---------+----------+---------+-----+--------+----------+---------+-----");
			System.out.printf("| %-10s |         %-8s                  |              %4s      |     %-10s      |          %-8s            |      %4s    |%n",rs.getInt("id"),rs.getString("name"),rs.getString("course"),rs.getDouble("balance"),rs.getString("status"),rs.getDouble("fees_paid"));
			System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
			System.out.println("+-------+---------------+-----------------+---------+----------+-----------++-------+---------------+-----------------+---------+----------+-----------+----------+-----------+");
		}
		else {
			System.out.println("No student found with mentioned id");
		}
		
		System.out.println("************");
		
	}


	//Add new admin details in the database
	public void registerNewAdmin(String username,String password) throws SQLException, IOException {
//		System.out.println("Enter username: ");
//		username = bfr.readLine();
//		System.out.println("Enter password: ");
//		password = bfr.readLine();
		String sel = "select * from userslist where username=?";
		pst = conn.prepareStatement(sel);
		pst.setString(1, username);
		rs = pst.executeQuery();
		if(rs.next()) {
			System.out.println("*******************");
			System.out.println("User Already Exists!");
		}
		else {
			String ins = "insert into userslist(username,password) values(?,?)";
			pst = conn.prepareStatement(ins);
			pst.setString(1, username);
			pst.setString(2, password);
			int ret = pst.executeUpdate();
			System.out.println("****************");
			if(ret>0) {
				System.out.println("Registration Successfull!");
			}
			System.out.println("***********");
		}
		
	}	

}
