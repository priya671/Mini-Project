package com.cap.cl.dao;

import java.sql.SQLException;

/**
 * all copy rights reserved to user priya kothare
 */

public interface StudentDAO {
	
	public void viewStudentBalance(int id,String password) throws SQLException, Exception; //view only balance using id
	
	public void payStudentFees(int id,String password) throws SQLException; //pay student fees using id
	
	public void getStudentInfoById(int id,String password) throws SQLException;//Get all student info using id

	public void getStudentfeeById(int id,String password) throws SQLException; //Get Fee paid by Student using id
}