package com.cap.cl.pojo;

/**
 * all copy rights reserved to user priya kothare
 */

//Getter and Setter methods of Student Class
//Constructor with field and without field of student Class
//Entity class or pojo

public class Student {
	private int studentid;
	private String studentname;
	private String course;
	private double studentbalance;
	private String studentstatus;
	private double tutionfeestatus;
	
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public double getStudentbalance() {
		return studentbalance;
	}
	
	public String getStudentstatus() {
		return studentstatus;
	}
	public void setStudentstatus(String studentstatus) {
		this.studentstatus = studentstatus;
	}
	public void setStudentbalance(double studentbalance) {
		this.studentbalance = studentbalance;
	}
	
	public double getTutionfeestatus() {
		return tutionfeestatus;
	}
	public void setTutionfeestatus(double d) {
		this.tutionfeestatus = d;
	}
	
	public Student(int studentid, String studentname, String course, double studentbalance,String status,int tutionfeestatus) {
		super();
		this.studentid = studentid;
		this.studentname = studentname;
		this.course = course;
		this.studentbalance = studentbalance;
		this.studentstatus = status;
		this.tutionfeestatus = tutionfeestatus;
	}
	
	public Student() {
		super();
	}
	@Override
	public String toString() {
		return "Student [studentid=" + studentid + ", studentname=" + studentname + ", course=" + course
				+ ", studentbalance=" + studentbalance + ", studentstatus=" + studentstatus + ", tutionfeestatus="
				+ tutionfeestatus + "]";
	}
	

}
