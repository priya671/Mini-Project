package com.cap.cl.dao;

/**
 * all copy rights reserved to user priya kothare
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cap.cl.main.StudentInformation;
import com.cap.cl.pojo.Student;

public class StudentDAOImpl implements StudentDAO {
	
	//creating studentinformation object to access methods
	StudentInformation studentinformation;
	Scanner scan = new Scanner(System.in);
	//to generate unique id
	int max = 99999;
	int min = 10000;

	public StudentDAOImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentDAOImpl(StudentInformation studentinformation) {
		super();
		this.studentinformation = studentinformation;
	}


	//Add New Student in the database
	@Override
	public void enrollStudent() {
		System.out.println("************");
		Student s = new Student();
		int id = (int) (Math.random()*(max-min+1)+min);
		s.setStudentid(id);
		//scan.nextLine();
		System.out.println("Enter student name: ");
		s.setStudentname(scan.nextLine());
		System.out.println("Enter student course: ");
		s.setCourse(scan.nextLine());
		System.out.println("Enter student balance: ");
		s.setStudentbalance(scan.nextDouble());
		scan.nextLine();
		System.out.println("Enter student status: ");
		s.setStudentstatus(scan.nextLine());
		System.out.println("Enter student tution fee paid amount: ");
		s.setTutionfeestatus(scan.nextDouble());
		s.setStudentbalance(s.getStudentbalance()-s.getTutionfeestatus());
		//Adding enrolled student with existing database values
		List<Student> studentinfo = new ArrayList<Student>();
		Student s1 = new Student(11111,"Anushka Joshi","JFS",40000,"Enrolled",20000);
		Student s2 = new Student(20009,"Sayli Patil","AWS",35000,"Re-entering",5000);
		Student s3 = new Student(34567,"Ashutosh Naik","SFT",20000,"Enrolled",0);
		Student s4 = new Student(43989,"Sonali Iyer","WD",25000,"Re-entering",0);
		Student s5 = new Student(53455,"Arjun Kothare","AWS",35000,"Enrolled",0);
		studentinfo.add(s1);
		studentinfo.add(s2);
		studentinfo.add(s3);
		studentinfo.add(s4);
		studentinfo.add(s5);
		studentinfo.add(s);
		studentinformation.StoreStudent(studentinfo);
		//studentinformation.getStudentsByIterator();
		StudentDAOImpl studentdaoimpl = new StudentDAOImpl(studentinformation);
		System.out.println("Student Registered Successfully!");
		System.out.println("Student unique id is: " + id);
		studentdaoimpl.viewAllStudentData();
		System.out.println("************");
	}

	//View student balance by student id
	@Override
	public void viewStudentBalance(int id) {
		System.out.println("************");
		Student s = studentinformation.getStudentById(id);
		try{
			System.out.println(s.getStudentname() + " balance = "+ s.getStudentbalance());
		}catch(Exception e) {
			System.out.println("No Student found with mentioned Id");
		}
		System.out.println("************");
		
	}

	//Pay Student Fees by ID
	@Override
	public void payStudentFees(int id) {
		System.out.println("************");
		Student s = studentinformation.getStudentById(id);
		try {
			System.out.println("Available Student Balance: " + s.getStudentbalance());
			System.out.println("Enter the tution fee amount to pay: ");
			int amt = scan.nextInt();
			if(amt>s.getStudentbalance()) {
				System.out.println("Insufficient Balance!");
			}
			else if(amt<=0) {
				System.out.println("Invalid Amount. Please try again!");
			}
			else {
				double available_amount = (s.getStudentbalance()-amt);
				System.out.println(amt + " paid successfully!");
				System.out.println("Available balance: " + available_amount);
				s.setStudentbalance(available_amount);
				double g = s.getTutionfeestatus();
				s.setTutionfeestatus(amt+g);
			}
		}catch(Exception e) { //if Student object is null it will invoke catch block
			System.out.println("No student found with mentioned Id");
		}
		System.out.println("************");
		
	}

//	@Override
//	public void showStudentStatus(int id) {
//		Student s = studentinformation.getStudentById(id);
//		if(s==null) {
//			System.out.println("No student found with mentioned id");
//		}
//		else {
//			System.out.println(s.getStudentname()+ " status = " + s.getStudentstatus());
//		}
//		
//	}
	
	//Fetch all the student information by ID
	@Override
	public void getStudentInfoById(int id) {
		System.out.println("************");
		Student s = studentinformation.getStudentById(id);
		if(s==null) {
			System.out.println("No student found with mentioned id");
		}
		else {
			System.out.println("Student Information of id= " + id);
			System.out.println("Student Id: " + s.getStudentid() + ", "+"Student name: " + s.getStudentname() + ", " + "Student course: " + s.getCourse() + ", "
			+ "Student Balance: " + s.getStudentbalance() + ", " + "Student status: " + s.getStudentstatus() + ", " + "Tution Fee Amount: " + s.getTutionfeestatus());
		}
		System.out.println("************");
		
	}

	//View All the student data in the database
	@Override
//	public void viewAllStudentData() {
//		System.out.println("******");
//		//Add all the student record in arraylist
//		for(Student students: studentinformation.getStudents()) {
//			System.out.println("Student[Student Id= " + students.getStudentid() + ", Student Name= " + students.getStudentname() +
//			", student course= " + students.getCourse() + ", Student balance= " + students.getStudentbalance()
//			+ ", student status= " + students.getStudentstatus() + "]");
//		}
//		System.out.println("******");
//	}
	
	//View All the student data in the database
	public void viewAllStudentData() {
		System.out.println("******");
		//Add all the student record in arraylist
		System.out.println("Student Id\tStudent Name\t             Student Course\t   Student Balance\tStudent Status\tTution Fee Paid Amount");
		for(Student students: studentinformation.getStudents()) {
			System.out.println(students.getStudentid()+ "\t" + "\t" + students.getStudentname() + "\t" + "\t         " + students.getCourse()+ "\t" + "\t" + "\t"+ students.getStudentbalance() + "\t" + "\t" + students.getStudentstatus()
			+ "\t" + "\t" + students.getTutionfeestatus());
		}
		System.out.println("******");
	}

	//Fetch all the students info of same status
	@Override
	public void filterBasedOnStatus(String status) {
		
		List<Student> slist = new ArrayList<Student>();
		slist = studentinformation.getStudentByStatus(status);
		if(slist==null) { //If status does not exist
			System.out.println("No such status found in the database!");
		}
		System.out.println("************");
		
	}

	//Update student data by Id
	@Override
	public void updateStudentData(int id){
		System.out.println("************");
		//int flag = 0;
		Student s = studentinformation.getStudentById(id);
		try {
		if(id==s.getStudentid()) { //If id exists
			System.out.println("Select the content to update");
			System.out.println("1.Student name \n2.Student course \n3.Student balance \n4.Student Status");
			System.out.println("Enter your choice: ");
			int choice=scan.nextInt();
			scan.nextLine();
			switch(choice) {
				case 1:
					System.out.println("Old name: " + s.getStudentname());
					System.out.println("Enter updated name: ");
					String name = scan.nextLine();
					s.setStudentname(name);
					System.out.println("Student name updated.");
					//flag = 1;
					break;
				case 2:
					System.out.println("Old course: " + s.getCourse());
					System.out.println("Enter update course: ");
					String course = scan.nextLine();
					s.setCourse(course);
					System.out.println("Student course updated");
					//flag = 1;
					break;
				case 3:
					System.out.println("Old balance: " + s.getStudentbalance());
					System.out.println("Enter updated balance: ");
					double balance = scan.nextDouble();
					s.setStudentbalance(balance);
					System.out.println("Student balance updated");
					//flag = 1;
					break;
				case 4:
					System.out.println("Old status: " + s.getStudentstatus());
					System.out.println("Enter updated status: ");
					String status = scan.next();
					s.setStudentstatus(status);
					System.out.println("Student Status updated");
					//flag = 1;
					break;
				default:
					System.out.println("****Invalid Choice! Please try again");
					System.out.println("\n");
			}
		}
		}catch(Exception e) { //if id does not exists
			System.out.println("Student id doesn't exist! Please try again.");
		}
		System.out.println("************");
		
	}

	//Delete student data by Id
	@Override
	public void deleteStudentData(int id) {
		System.out.println("************");
		Student s = studentinformation.getStudentById(id);
		try {
			if(id==s.getStudentid()) { //if id exists
				List<Student> slist = studentinformation.getStudents();
				slist.remove(s); //remove the entire record
				System.out.println("Student deleted successfully!");
			}
		}catch(Exception e) { //if id does not exist
			System.out.println("Student Id doesn't exist");
		}
		System.out.println("************");		
	}

}

//MAintain two panels admin and user
//student can register and view balance and pay fees
//Switch case: admin and user
//In userlist have normal and admin user
//Use iterator to display the database records
//Maintain paid tution fees record also. If tution fees is paid
//add that record into the database


