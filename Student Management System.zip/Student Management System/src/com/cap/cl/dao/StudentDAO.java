package com.cap.cl.dao;

/**
 * all copy rights reserved to user priya kothare
 */

public interface StudentDAO {
	
	public void enrollStudent(); //adding student data in the database
	
	public void viewStudentBalance(int id); //view only balance using id
	
	public void payStudentFees(int id); //pay student fees using id
	
	//public void showStudentStatus(int id);
	
	public void filterBasedOnStatus(String status);//view all the students of same status
	
	public void getStudentInfoById(int id);//Get all student info using id
	
	public void viewAllStudentData();//View entire database records
	
	public void updateStudentData(int id); //update student record using id
	
	public void deleteStudentData(int id); //delete student record using id

}
